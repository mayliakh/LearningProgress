console.log("Hi Friends")
alert("Selalu jaga kesehatan,laksanakan prokes,dan jangan keluar bila tidak ada keperluan.")